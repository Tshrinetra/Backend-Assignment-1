const operation = require("./operation.js");
console.log(operation.sum(2,3));
console.log(operation.divide(4,4));
console.log(operation.subtraction(3,3));
console.log(operation.multiple(10,10))