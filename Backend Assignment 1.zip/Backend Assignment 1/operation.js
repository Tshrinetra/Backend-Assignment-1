function sum(a, b) {
	return a + b;
}
function subtraction(a, b) {
	return a - b;
}
function divide(a, b) {
	return a / b;
}
function multiple(a, b) {
	return a * b;
}
module.exports = {subtraction,sum,multiple,divide}